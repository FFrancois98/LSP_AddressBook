
public class LSP_AddressBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// there is nothing in the main because all of the testing is in the JUint test cases.

	}

}

